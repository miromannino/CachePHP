#!/bin/bash

cd 'test1'

rm -f *
