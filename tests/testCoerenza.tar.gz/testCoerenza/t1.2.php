<?php
	
	for($i=0; $i<10000; $i++){
		touch('prova.txt');
		//time_nanosleep(0,1000000);
	}
	
?>
