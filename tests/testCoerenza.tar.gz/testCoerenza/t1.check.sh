#!/bin/bash

cd 'test1'

c=$(md5sum * | awk '{print $1}' | sort | uniq | wc -l)

if [ $c = '2' ]; then
	echo "Test OK"
else
	echo "Test Fail"
fi
