#!/bin/bash

url='http://localhost/CachePHP/tests/testCoerenza'

wget "$url/t1.2.php" &> /dev/null
wget "$url/t1.php?t=1" &> /dev/null
wget "$url/t1.php?t=2" &> /dev/null
wget "$url/t1.2.php" &> /dev/null
wget "$url/t1.php?t=3" &> /dev/null
wget "$url/t1.php?t=4" &> /dev/null
wget "$url/t1.2.php" &> /dev/null
wget "$url/t1.php?t=5" &> /dev/null
wget "$url/t1.php?t=6" &> /dev/null
wget "$url/t1.2.php" &> /dev/null
wget "$url/t1.php?t=7" &> /dev/null
wget "$url/t1.php?t=8" &> /dev/null
wget "$url/t1.2.php" &> /dev/null
wget "$url/t1.php?t=9" &> /dev/null
wget "$url/t1.php?t=10" &> /dev/null
