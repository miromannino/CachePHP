<?php

	require("../../CachePHP/Cache.php");
	
	$s = new CachePHP_Cache("testcache");
	$s->setCacheFile('t1');
	$s->setDependFile(array('prova.txt'));
	
	for($i=0; $i<1000; $i++){
		//time_nanosleep(0,1000000);
		if ($s->get($content)){
			file_put_contents('test1/t' . $_GET['t'] . '.' . $i . '.txt', $content);
		}else{
			if ((time() % 2) == 0) $c = 'a'; else $c = 'b';
		
			$str = '';
			for($j=0; $j<5000; $j++) $str .= $c;
			
			$s->put($str);
		}
	}
	
?>
